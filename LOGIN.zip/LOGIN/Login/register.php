<!DOCTYPE html>
<html>

<?php
	require 'koneksi.php';
	if (isset($_POST['submit'])) {
		
		$username = $_POST['username'];
		$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
		$privileges = $_POST['privileges'];

		if($username==''){
			echo "Register Failed";
		} else{
			$query = mysql_query("INSERT into login VALUES('','$username','$password','$privileges')");
			header('location: ./index.php');
		}
	}
?>
<head>
	<title>Register</title>
	<link rel="stylesheet" type="text/css" href="../semantic/dist/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="css.css">
	<script src="../semantic/dist/semantic.min.js"></script>
</head>
	<body>
		<div class="ui three column center aligned grid">
			<div class="column">
				<h2 class="ui teal image header">
					<div class="content">Sign In Dulu Bro</div>
				</h2>
				<form class="ui form" method="POST" onsubmit="return validasi_input(this)">
					<div class="ui stacked segment">
						<div class="field">
							<div class="ui left icon input">
								<i class="user icon">
								</i>
								<input type="text" name="username" placeholder="Username">
							</div>
						</div>
						<div class="field">
							<div class="ui left icon input">
								<i class="lock icon">
								</i>
								<input type="password" name="password" placeholder="Password">
							</div>
						</div>
						<div class="field">
							<div class="ui left icon input">
								<select class="ui dropdown" name="privileges">
							        <option value="">Pilih Hak Akses</option>
								    <option value="1">Admin</option>
								    <option value="0">User</option>
							    </select>
							</div>
						</div>
					</div>
					<input class="ui fluid large teal submit button" type="submit" value="Sign IN" name="submit">
				</form>
			</div>
		</div>
	</body>
</html>